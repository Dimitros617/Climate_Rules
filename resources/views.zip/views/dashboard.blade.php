@section('title','Climate rules')


<script src="/js/main.js"></script>

<x-app-layout>
    <x-slot name="header">



    </x-slot>

    <div class="pageTitle mb-4 mt-8 text-su-shadow-white">Climate rules</div>

Cau

                    </div>







</x-app-layout>
